//
// Created by LEI XU on 4/27/19.
//

#ifndef RASTERIZER_TEXTURE_H
#define RASTERIZER_TEXTURE_H
#include "global.hpp"
#include <eigen3/Eigen/Eigen>
#include <opencv2/opencv.hpp>
class Texture{
private:
    cv::Mat image_data;

public:
    Texture(const std::string& name)
    {
        image_data = cv::imread(name);
        cv::cvtColor(image_data, image_data, cv::COLOR_RGB2BGR);
        width = image_data.cols;
        height = image_data.rows;
    }

    int width, height;

    Eigen::Vector3f getColor(float u, float v)
    {
        auto u_img = u * width;
        auto v_img = (1 - v) *height;
        auto color = image_data.at<cv::Vec3b>(v_img, u_img);
        return Eigen::Vector3f(color[0], color[1], color[2]);
    }

    Eigen::Vector3f getColorBilinear(float u, float v)
    {
        std::cout << "getColorBilinear width"<< width << std::endl;
        std::cout << "getColorBilinear height "<< height << std::endl;

        auto u_img = u * width;
        auto v_img = (1 - v) * height;

        Eigen::Vector2f u00(std::floor(u_img)*1.f,std::floor(v_img)*1.f);
        Eigen::Vector2f u10(std::ceil(u_img)*1.f,std::floor(v_img)*1.f);
        Eigen::Vector2f u01(std::floor(u_img)*1.f,std::ceil(v_img)*1.f);
        Eigen::Vector2f u11(std::ceil(u_img)*1.f,std::ceil(v_img)*1.f);

        float s = (u_img - u00.x())/width;
        float t = (v_img - u00.y())/height;

        Eigen::Vector3f u0 = lerp(s,getColor(u00.x()/width,u00.y()/height),getColor(u10.x()/width,u10.y()/height));
        Eigen::Vector3f u1 = lerp(s,getColor(u01.x()/width,u01.y()/height),getColor(u11.x()/width,u11.y()/height));
        auto color = lerp(t,u0,u1);
        //auto color = image_data.at<cv::Vec3b>(v_img, u_img);
        return Eigen::Vector3f(color[0], color[1], color[2]);
    }

    Eigen::Vector3f lerp(float coef, Eigen::Vector3f a,Eigen::Vector3f b)
    {
        return (1- coef)* a + b * coef ;
    }

};
#endif //RASTERIZER_TEXTURE_H
